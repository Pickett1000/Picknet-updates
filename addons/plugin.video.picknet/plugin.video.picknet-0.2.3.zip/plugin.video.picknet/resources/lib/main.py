from __future__ import annotations

import json
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
API_ROOT = "https://api.themoviedb.org/3"
TMDB_API_KEY = "adb48b8b6c1161f0f0b88cb0dec37033"
IMAGE_ROOT = "https://image.tmdb.org/t/p/"


def setting(name: str, fallback: str = "") -> str:
    return ADDON.getSettingString(name).strip() or fallback


def plugin_url(**params) -> str:
    return BASE_URL + "?" + urlencode(params)


def api(path: str, **params):
    key = TMDB_API_KEY
    params.setdefault("language", setting("language", "en-US"))
    params["api_key"] = key
    request = Request(API_ROOT + path + "?" + urlencode(params), headers={"User-Agent": "Picknet/0.2"})
    try:
        with urlopen(request, timeout=15) as response:
            return json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, ValueError) as exc:
        xbmc.log("Picknet catalog request failed: %s" % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Picknet", "Catalog is temporarily unavailable", xbmcgui.NOTIFICATION_ERROR)
        return None


def image(path: str | None, size: str) -> str:
    return IMAGE_ROOT + size + path if path else ""


def add_folder(label: str, action: str, **params):
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action=action, **params), item, True)


def media_type(entry):
    kind = entry.get("media_type")
    if kind in ("movie", "tv", "person"):
        return kind
    return "tv" if "first_air_date" in entry or "name" in entry else "movie"


def crew_play_movie(data):
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.thecrew)"):
        xbmcgui.Dialog().ok("Picknet", "The Crew is not installed. Install and configure The Crew, then try again.")
        return
    title = data.get("title") or "Movie"
    release = data.get("release_date") or ""
    year = release[:4] if len(release) >= 4 else ""
    external = api("/movie/%s/external_ids" % data.get("id")) or {}
    imdb = external.get("imdb_id") or ""
    meta = {
        "title": title, "originaltitle": data.get("original_title") or title,
        "year": year, "imdb": imdb, "code": imdb, "tmdb": str(data.get("id") or ""),
        "plot": data.get("overview") or "", "poster": image(data.get("poster_path"), "w500"),
        "fanart": image(data.get("backdrop_path"), "original"), "mediatype": "movie"
    }
    uri = "plugin://plugin.video.thecrew/?" + urlencode({
        "action": "play", "title": title, "year": year, "imdb": imdb,
        "meta": json.dumps(meta, separators=(",", ":")), "t": str(int(time.time()))
    })
    xbmc.executebuiltin("PlayMedia(%s)" % uri)


def add_media(entry):
    kind = media_type(entry)
    if kind == "person":
        title = entry.get("name") or "Unknown"
        item = xbmcgui.ListItem(label=title)
        item.setArt({"thumb": image(entry.get("profile_path"), "w500")})
        item.setInfo("video", {"title": title, "plot": entry.get("known_for_department", "")})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="person", id=entry.get("id", "")), item, True)
        return

    title = entry.get("title") or entry.get("name") or "Untitled"
    date = entry.get("release_date") or entry.get("first_air_date") or ""
    info = {
        "title": title,
        "plot": entry.get("overview") or "",
        "year": int(date[:4]) if len(date) >= 4 and date[:4].isdigit() else 0,
        "rating": float(entry.get("vote_average") or 0),
        "mediatype": "tvshow" if kind == "tv" else "movie",
    }
    item = xbmcgui.ListItem(label=title)
    item.setInfo("video", info)
    item.setArt({
        "poster": image(entry.get("poster_path"), "w500"),
        "thumb": image(entry.get("poster_path"), "w500"),
        "fanart": image(entry.get("backdrop_path"), "original"),
    })
    if kind == "movie":
        item.setProperty("IsPlayable", "true")
        target = plugin_url(action="play", media="movie", id=entry.get("id", ""))
        is_folder = False
    else:
        item.setProperty("IsPlayable", "false")
        target = plugin_url(action="details", media=kind, id=entry.get("id", ""))
        is_folder = True
    xbmcplugin.addDirectoryItem(HANDLE, target, item, is_folder)


def finish(content="videos"):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    if content == "videos":
        # Prefer Picknet's poster-wall presentation instead of Kodi's file list.
        xbmcplugin.setPluginCategory(HANDLE, "Picknet")
        xbmc.executebuiltin("Container.SetViewMode(51)")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def root():
    add_folder("Search everything", "search")
    add_folder("Trending now", "list", endpoint="/trending/all/week", title="Trending now")
    add_folder("New movies", "list", endpoint="/movie/now_playing", title="New movies")
    add_folder("New TV shows", "list", endpoint="/tv/on_the_air", title="New TV shows")
    add_folder("Netflix", "platform", provider="8", title="Netflix")
    add_folder("HBO Max", "platform", provider="1899", title="HBO Max")
    add_folder("Disney+", "platform", provider="337", title="Disney+")
    add_folder("Prime Video", "platform", provider="9", title="Prime Video")
    add_folder("Settings", "settings")
    finish("files")


def search(query: str = ""):
    query = (query or "").strip()
    if not query:
        keyboard = xbmc.Keyboard("", "Search Picknet")
        keyboard.doModal()
        if not keyboard.isConfirmed() or not keyboard.getText().strip():
            finish()
            return
        query = keyboard.getText().strip()
    payload = api("/search/multi", query=query, include_adult="false")
    def norm(value):
        return "".join(ch.lower() for ch in (value or "") if ch.isalnum())
    q = norm(query)
    def rank(entry):
        title = entry.get("title") or entry.get("name") or ""
        t = norm(title)
        exact = 1 if t == q else 0
        starts = 1 if t.startswith(q) else 0
        contains = 1 if q and q in t else 0
        kind = media_type(entry)
        media_boost = 1 if kind in ("tv","movie") else 0
        return (exact, starts, contains, media_boost, float(entry.get("popularity") or 0))
    results = (payload or {}).get("results", [])
    results.sort(key=rank, reverse=True)
    for entry in results:
        add_media(entry)
    finish("videos")


def listing(endpoint, **extra):
    payload = api(endpoint, **extra)
    for entry in (payload or {}).get("results", []):
        add_media(entry)
    finish("videos")


def provider_assets():
    wanted = {8:"Netflix",337:"Disney+",1899:"Max",9:"Prime Video",15:"Hulu",531:"Paramount+",386:"Peacock",350:"Apple TV+",43:"STARZ",11:"MGM+",1853:"Paramount+ with SHOWTIME",151:"BritBox",87:"Acorn TV",528:"AMC+",99:"Shudder"}
    data = api("/watch/providers/movie", watch_region=setting("region", "US"))
    found = {}
    for row in (data or {}).get("results", []):
        pid = int(row.get("provider_id") or 0)
        if pid not in wanted:
            continue
        logo = row.get("logo_path") or ""
        found[pid] = logo
        li = xbmcgui.ListItem(label=wanted[pid])
        if logo:
            li.setArt({"thumb": image(logo, "w300"), "icon": image(logo, "w300")})
        li.setProperty("Picknet.ProviderId", str(pid))
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="platform", provider=pid, title=wanted[pid]), li, True)
    if 531 not in found:
        fallback = found.get(1853, "")
        li = xbmcgui.ListItem(label="Paramount+")
        if fallback:
            li.setArt({"thumb": image(fallback, "w300"), "icon": image(fallback, "w300")})
        li.setProperty("Picknet.ProviderId", "531")
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="platform", provider=531, title="Paramount+"), li, True)
    finish("files")

def platform(provider: str, title: str):
    # A service card opens directly into a unified Picknet poster wall instead
    # of an intermediate Kodi-style folder menu.
    common = {
        "watch_region": setting("region", "US"),
        "with_watch_providers": provider,
        "sort_by": "popularity.desc",
        "include_adult": "false",
    }
    combined = []
    movies = api("/discover/movie", **common)
    shows = api("/discover/tv", **common)
    for entry in (movies or {}).get("results", []):
        entry["media_type"] = "movie"
        combined.append(entry)
    for entry in (shows or {}).get("results", []):
        entry["media_type"] = "tv"
        combined.append(entry)
    combined.sort(key=lambda row: float(row.get("popularity") or 0), reverse=True)
    xbmcplugin.setPluginCategory(HANDLE, title)
    for entry in combined[:40]:
        add_media(entry)
    finish("videos")


def discover(media: str, provider: str, sort: str):
    params = {
        "watch_region": setting("region", "US"),
        "with_watch_providers": provider,
        "sort_by": sort,
        "include_adult": "false",
    }
    if sort.endswith("date.desc"):
        from datetime import date
        params["primary_release_date.lte" if media == "movie" else "first_air_date.lte"] = date.today().isoformat()
    listing("/discover/" + media, **params)


def details(media: str, item_id: str):
    data = api("/%s/%s" % (media, item_id), append_to_response="recommendations,similar,videos")
    if not data:
        finish()
        return
    title = data.get("title") or data.get("name") or "Title"
    overview = xbmcgui.ListItem(label=title)
    overview.setInfo("video", {"title": title, "plot": data.get("overview", ""), "rating": data.get("vote_average", 0)})
    overview.setArt({"poster": image(data.get("poster_path"), "w500"), "fanart": image(data.get("backdrop_path"), "original")})
    xbmcplugin.addDirectoryItem(HANDLE, "", overview, False)
    if media == "tv":
        for season in data.get("seasons", []):
            add_media({"id": item_id, "name": season.get("name"), "overview": season.get("overview"), "poster_path": season.get("poster_path"), "media_type": "tv"})
    recommendations = data.get("recommendations", {}).get("results", [])[:20]
    for entry in recommendations:
        add_media(entry)
    finish("videos")


def person(item_id: str):
    data = api("/person/%s/combined_credits" % item_id)
    credits = (data or {}).get("cast", [])
    credits.sort(key=lambda row: float(row.get("popularity") or 0), reverse=True)
    for entry in credits[:40]:
        add_media(entry)
    finish("videos")


def router():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get("action", "root")
    if action == "root": root()
    elif action == "search": search(params.get("query", ""))
    elif action == "list": listing(params.get("endpoint", "/trending/all/week"))
    elif action == "provider_assets": provider_assets()
    elif action == "platform": platform(params.get("provider", "8"), params.get("title", "Platform"))
    elif action == "discover": discover(params.get("media", "movie"), params.get("provider", "8"), params.get("sort", "popularity.desc"))
    elif action == "details": details(params.get("media", "movie"), params.get("id", ""))
    elif action == "play":
        data = api("/movie/%s" % params.get("id", ""))
        if data: crew_play_movie(data)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    elif action == "person": person(params.get("id", ""))
    elif action == "ui":
        xbmc.executebuiltin("RunAddon(script.picknet.ui)")
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    elif action == "settings":
        ADDON.openSettings(); finish("files")
    else: root()


if __name__ == "__main__":
    router()
