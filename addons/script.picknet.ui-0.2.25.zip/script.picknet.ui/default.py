import json
import xbmc
import xbmcaddon
import xbmcgui

CATALOG = "plugin://plugin.video.picknet/"

PRIME_CHANNELS = [("Prime Video","9"),("Max","1899"),("STARZ","43"),("MGM+","11"),("Paramount+","531"),("Apple TV+","350"),("BritBox","151"),("Acorn TV","87"),("AMC+","528"),("Shudder","99")]

PROVIDERS = {
    1101: ("Netflix", "8"), 1102: ("Disney+", "337"), 1103: ("Max", "1899"),
    1104: ("Prime Video", "9"), 1105: ("Hulu", "15"), 1106: ("Paramount+", "531"),
    1107: ("Peacock", "386"), 1108: ("Apple TV+", "350"),
}

def directory(url):
    query = {"jsonrpc":"2.0","id":1,"method":"Files.GetDirectory","params":{
        "directory":url,"media":"video",
        "properties":["title","plot","year","rating","art"]
    }}
    try:
        data=json.loads(xbmc.executeJSONRPC(json.dumps(query)))
        return data.get("result",{}).get("files",[])
    except Exception as exc:
        xbmc.log("Picknet UI directory error: %s" % exc, xbmc.LOGERROR)
        return []

def li_from(row):
    item=xbmcgui.ListItem(label=row.get("label") or row.get("title") or "Untitled")
    art=row.get("art") or {}
    item.setArt({"poster":art.get("poster") or art.get("thumb") or "",
                 "thumb":art.get("thumb") or art.get("poster") or "",
                 "fanart":art.get("fanart") or ""})
    item.setProperty("Picknet.Path", row.get("file") or "")
    item.setProperty("Picknet.FileType", "directory" if (row.get("file") or "").startswith("plugin://") else "file")
    return item

class PicknetHome(xbmcgui.WindowXML):
    def onInit(self):
        self.setProperty("Picknet.ServiceMode","false")
        self.setProperty("Picknet.ServiceName","")
        self.setProperty("Picknet.SearchMode","false")
        self.setProperty("Picknet.SearchTitle","")
        self._load_provider_art()
        self.setProperty("Picknet.SeasonalTheme","GobbleVision")
        self._load_home()

    def _load_provider_art(self):
        rows = directory(CATALOG+"?action=provider_assets")
        by_name = {}
        for row in rows:
            label = (row.get("label") or "").strip()
            art = (row.get("art") or {}).get("thumb") or ""
            if label and art:
                by_name[label] = art
                normalized = label.lower().replace(" ", "")
                if "paramount" in normalized:
                    by_name["Paramount+"] = art
        home_names = ["Netflix","Disney+","Max","Prime Video","Hulu","Paramount+","Peacock","Apple TV+"]
        extra_names = ["STARZ","MGM+","Paramount+ with SHOWTIME","BritBox","Acorn TV","AMC+","Shudder"]
        aliases = {
            "Netflix": ["Netflix"],
            "Disney+": ["Disney Plus", "Disney+"],
            "Max": ["Max", "HBO Max"],
            "Prime Video": ["Amazon Prime Video", "Prime Video"],
            "Hulu": ["Hulu"],
            "Paramount+": ["Paramount Plus", "Paramount+ with SHOWTIME", "Paramount+"],
            "Peacock": ["Peacock Premium", "Peacock"],
            "Apple TV+": ["Apple TV Plus", "Apple TV+"],
        }
        for idx,name in enumerate(home_names,1):
            art = ""
            for candidate in aliases.get(name,[name]):
                if by_name.get(candidate):
                    art = by_name[candidate]
                    break
            if not art:
                needle = name.lower().replace("+","").replace(" ","")
                for candidate,value in by_name.items():
                    normalized = candidate.lower().replace("+","").replace(" ","")
                    if needle and needle in normalized:
                        art = value
                        break
            if name == "Paramount+" and not art:
                art = "https://image.tmdb.org/t/p/w300/fts6X10Jn4QT0X6ac3udKEn2tJA.jpg"
            self.setProperty("Picknet.ProviderLogo.%d" % idx, art)
        for idx,name in enumerate(extra_names,9):
            self.setProperty("Picknet.ProviderLogo.%d" % idx, by_name.get(name,""))

    def _fill(self, control_id, url, limit=20):
        control=self.getControl(control_id)
        control.reset()
        rows=directory(url)
        if rows and rows[0].get("label")=="..":
            rows=rows[1:]
        control.addItems([li_from(x) for x in rows[:limit]])

    def _load_home(self):
        self._fill(2001, CATALOG+"?action=list&endpoint=%2Ftrending%2Fall%2Fweek", 20)
        self._fill(2002, CATALOG+"?action=list&endpoint=%2Fmovie%2Fpopular", 20)
        self._fill(2003, CATALOG+"?action=list&endpoint=%2Ftv%2Fpopular", 20)

    def _service_url(self, provider, media, sort):
        return (CATALOG+"?action=discover&media=%s&provider=%s&sort=%s" %
                (media, provider, sort))

    def _open_service(self, name, provider):
        self.setProperty("Picknet.ServiceName",name)
        self.setProperty("Picknet.ServiceMode","true")
        self.setProperty("Picknet.PrimeMode","true" if provider=="9" else "false")
        self._fill(2101,self._service_url(provider,"movie","popularity.desc"))
        self._fill(2102,self._service_url(provider,"tv","popularity.desc"))
        self._fill(2103,self._service_url(provider,"movie","primary_release_date.desc"))
        self._fill(2104,self._service_url(provider,"tv","first_air_date.desc"))
        if provider=="9":
            self.setFocusId(2201)
        else:
            self.setFocusId(2101)

    def _open_prime_channel(self, control_id):
        channels = {2200+i:ch for i,ch in enumerate(PRIME_CHANNELS,1)}
        if control_id in channels:
            self._open_service(*channels[control_id])

    def _open_item(self, control_id):
        item=self.getControl(control_id).getSelectedItem()
        if not item: return
        path=item.getProperty("Picknet.Path")
        if not path: return
        if item.getProperty("Picknet.FileType")=="file":
            xbmc.executebuiltin("PlayMedia(%s)" % path)
        else:
            xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % path)

    def onClick(self, control_id):
        if 2201 <= control_id <= 2210:
            self._open_prime_channel(control_id); return
        if control_id in PROVIDERS:
            self._open_service(*PROVIDERS[control_id]); return
        if control_id in (2001,2002,2003,2101,2102,2103,2104,2301):
            self._open_item(control_id); return
        if 2401 <= control_id <= 2408:
            seasonal_queries = [
                "thanksgiving", "thanksgiving comedy", "family holiday",
                "feel good family", "thanksgiving", "kids thanksgiving",
                "holiday classics", "christmas"
            ]
            query = seasonal_queries[control_id - 2401]
            self.setProperty("Picknet.SearchMode","true")
            self.setProperty("Picknet.SearchTitle","GobbleVision: " + query.title())
            self._fill(2301, CATALOG+"?action=search&query="+query.replace(" ", "%20"), 40)
            self.setFocusId(2301)
            return
        if control_id==1203:
            keyboard = xbmc.Keyboard("", "Search Picknet")
            keyboard.doModal()
            if keyboard.isConfirmed():
                query = keyboard.getText().strip()
                if query:
                    self.setProperty("Picknet.SearchMode","true")
                    self.setProperty("Picknet.SearchTitle",'Search results for "%s"' % query)
                    self._fill(2301, CATALOG+"?action=search&query="+query.replace(" ", "%20"), 40)
                    self.setFocusId(2301)
            return
        if control_id==1204:
            xbmc.executebuiltin("ActivateWindow(Settings)")
            return
        if control_id==1205:
            xbmc.executebuiltin("ActivateWindow(AddonBrowser)")
            return

    def onAction(self, action):
        if action.getId() in (9,10,92) and self.getProperty("Picknet.SearchMode")=="true":
            self.setProperty("Picknet.SearchMode","false")
            self.setProperty("Picknet.SearchTitle","")
            self.setFocusId(1203)
            return
        if action.getId() in (9,10,92) and self.getProperty("Picknet.ServiceMode")=="true":
            self.setProperty("Picknet.ServiceMode","false")
            self.setProperty("Picknet.PrimeMode","false")
            self.setFocusId(1101)
            return
        super().onAction(action)

addon_path=xbmcaddon.Addon().getAddonInfo("path")
PicknetHome("picknet-home.xml", addon_path, "Default", "1080i").doModal()
